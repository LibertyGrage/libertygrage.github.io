ROADSTER X for GTA IV
Version 1.0.1 (2026-10-18), build 659ead3, plugin a7871a71
==============================================================================

A from-scratch drivable hypercar add-on for Grand Theft Auto IV: The Complete
Edition (PC).

Roadster X is a fictional two-seat electric hypercar for GTA IV that can jump,
hover and fly on ten cold-gas thrusters. Hop over traffic, hold a jump to keep
rising, hover above the city, spin it round, throw it into tricks, and let the
thrusters catch you before you hit the ground. Or just drive it: it has an
active rear wing, fan downforce and butterfly doors. It's an add-on car, so no
stock car is replaced.

FEATURES
========

- Add-on car roadsterx: spawn it with your trainer. Nothing in the game is
  replaced.
- Jump: tap to hop over traffic. Hold to jump higher: the car keeps rising
  while you hold, so you choose the height. Let go and it drops onto a soft
  landing.
- Hover and fly: double-tap to rise and hover. Climb with the jump button or
  the accelerator, or look up to climb straight up. Descend and travel with
  the stick, and boost. Double-tap again to drop: the thrusters catch the car
  just above the ground. In the air, one press of the jump button fires the
  jets again.
- Air tricks: hold the trick button in the air to turn the car freely: flips,
  rolls, spins. Push forward to keep moving while you do it. Kickflips on the
  road, and quick 180 and 360 spins.
- Soft landings: jumps, ramp jumps and ledge drops are cushioned near the
  ground automatically.
- Turn on the spot: from a standstill the car pivots smoothly; push further to
  turn faster. Powered drifts when moving.
- Ten thrusters with white vapor jets, trails and a glow at night.
- Active rear wing: Auto, Downforce, Airbrake and Stowed modes.
- Speed-scaled downforce with fan suction for grip.
- Water rescue: drive into water and the thrusters lift you back out (can be
  turned off).
- On-screen systems panel with gauges and the controls that matter right now.
- 49 original synthesized sounds: thrusters, wing servo, doors, motor.
- One settings file (plugins\RoadsterX.ini) with a comment on every line. It
  reloads while you play.

REQUIREMENTS
============

- Grand Theft Auto IV: The Complete Edition for PC, version 1.2.0.59 (Steam or
  Rockstar Games Launcher). Windows, or a Mac with CrossOver.
- FusionFix (https://github.com/ThirteenAG/GTAIV.EFLC.FusionFix/releases)
  5.1.1 or newer (tested with 5.1.1 and 5.1.2). It loads the plugin and the
  car's files from the update folder.
- Aru's C++ ScriptHook 0.5.1 with the Complete Edition hook fix
  (https://www.lcpdfr.com/downloads/gta4mods/g17media/26726-hook-fixes-for-complete-edition/)
  (ScriptHook.dll + aCompleteEditionHook.asi). The car's systems run as a
  ScriptHook script.
- Optional: a trainer that spawns add-on cars by model name, for example
  Liberty's Legacy (https://www.nexusmods.com/gta4/mods/100) 2.4.1.

None of these are included in the download.

DOWNLOAD AND INSTALL
====================

Before you start
----------------

1. Back up your GTA IV folder (or at least update\ and plugins\).
2. Install the requirements from the README: FusionFix, then ScriptHook with
   aCompleteEditionHook.asi. Start the game once to check that they work.

What's in the zip
-----------------

    RoadsterX-<version>\
      Game Folder\
        plugins\RoadsterX.asi          the car's systems (thrusters, flight, wing, panel)
        plugins\RoadsterX.ini          every setting, one comment per line
        plugins\RoadsterX\sfx\*.wav    the car's sounds
        update\z-RoadsterX\roadsterx.img        the model and its textures
        update\common\text\<language>8.gxt      the car's name and on-screen text (7 languages)
      Data Lines\
        vehicles.ide.txt  carcols.dat.txt  handling.dat.txt   one line each, to paste
      README.txt  LICENSE.txt  CHANGELOG.txt

Install
-------

1. Download RoadsterX-<version>.zip from the download section and unzip it.
2. Open its Game Folder and copy the two folders inside it, plugins and
   update, into your GTA IV folder (the one with GTAIV.exe). Let them merge
   with the folders that are already there.
3. Add the three lines from Data Lines to the game's data files:
   - In your GTA IV folder, open update\common\data. If vehicles.ide,
     carcols.dat or handling.dat is missing there, copy it in first from
     common\data. Never edit the files in common\data itself.
   - Open each .txt in Data Lines. It says which file the line goes into and
     where. Paste the line there with a plain text editor such as Notepad, and
     save.
4. Start the game and spawn the car by its model name, roadsterx, with your
   trainer. Liberty's Legacy shows add-on cars from Liberty's
   Legacy\Lists\addon_vehicle_models.txt: add the line roadsterx there.
5. Get in. The systems switch on and the controls appear on screen.

On a Mac with CrossOver
-----------------------

Do the same inside your CrossOver bottle:

1. In CrossOver, open the bottle's C: drive and go to the GTA IV folder,
   usually Program Files (x86)\Steam\steamapps\common\Grand Theft Auto
   IV\GTAIV.
2. Follow steps 1 to 5 above in that folder.
3. If no ASI mod loads at all, set a DLL override in the bottle's Wine
   configuration: dinput8 = native, builtin (FusionFix's own readme explains
   this).

Uninstall
---------

1. Delete these from your GTA IV folder:
   - plugins\RoadsterX.asi, plugins\RoadsterX.ini and the folder
     plugins\RoadsterX\
   - the folder update\z-RoadsterX\
   - the seven Roadster X text files update\common\text\*8.gxt: american8,
     french8, german8, italian8, japanese8, russian8 and spanish8. Check first
     that no other mod uses them.
2. Remove the three Roadster X lines from update\common\data\vehicles.ide,
   carcols.dat and handling.dat. If you copied those files in only for this
   mod, you can delete them instead.

Troubleshooting
---------------

- The car doesn't spawn, or its name shows wrong: Fix: Check the vehicles.ide
  and carcols.dat lines, and that update\z-RoadsterX\roadsterx.img is in
  place.
- It drives, but jumping, flying and the thrusters do nothing: Fix: ScriptHook
  isn't loading: check ScriptHook.dll and aCompleteEditionHook.asi in the game
  folder. plugins\RoadsterX.log says what loaded.
- No ASI mod loads at all (Mac): Fix: Set the dinput8 DLL override described
  above.
- "Roadster X systems are OFF": Fix: Turn them on: hold LB and click R3
  (keyboard: K).
- The on-screen panel hides something: Fix: Hide it in plugins\RoadsterX.ini
  with [Hud] Show=0, or move it with PanelX and PanelBottom.
- Another mod's text disappeared, or the car shows no name: Fix: Both use
  update\common\text\*8.gxt. Tell us which mod and we'll release a version
  with another text slot.
- The handling feels wrong: Fix: Check that the handling.dat line went into
  update\common\data\handling.dat and that no other mod uses the ROADSTERX
  row.

When you report a problem, attach plugins\RoadsterX.log and say which game
version you have.

CONTROLS
========

These are for the car's own systems. Driving itself (accelerate, brake, steer,
horn, camera) stays the game's. Controller buttons use Xbox names. The game
shows the controls for the moment on screen when you get in.

Systems
-------

- Systems on / off: Keyboard: K, Controller: hold LB, click R3
- Wing mode: Auto, Downforce, Airbrake, Stowed: Keyboard: U, Controller: none:
  set [Wing] StartMode in the settings file

On the road
-----------

- Jump over traffic (lands by itself): Keyboard: tap E, Controller: tap LB
- Higher jump: it keeps rising while you hold, so the hold sets the height;
  let go to drop onto the soft landing: Keyboard: hold E, Controller: hold LB
- Rise and hover: Keyboard: E E (double-tap), Controller: LB LB
- Boost: Keyboard: hold R, Controller: hold A
- 180 spin toward the stick (centred: the way the car turns): Keyboard: R R,
  Controller: A A
- 360 spin: Keyboard: R R R, Controller: A A A
- Drift (and quick 180): Keyboard: hold Space + A / D, Controller: hold RB +
  steer
- From a standstill: turn smoothly on the spot (push further to turn faster):
  Keyboard: hold Space + A / D, Controller: hold RB + left / right
- Kickflip (stick picks the trick; centred: a roll): Keyboard: Q Q,
  Controller: RB RB

In the hover
------------

- Climb: Keyboard: hold E or W, Controller: hold LB or RT
- Climb straight up (look up): Controller: right stick up
- One 3 m step up: Keyboard: tap E, Controller: tap LB
- Descend and land (tap: one step down): Keyboard: S, Controller: LT
- Travel forward / back (a gentle lean, height held): Keyboard: Left Shift /
  Left Ctrl, Controller: left stick forward / back
- Turn: Keyboard: A / D, Controller: left stick left / right
- Boost: Keyboard: hold R, Controller: hold A
- 180 / 360 spin: Keyboard: R R / R R R, Controller: A A / A A A
- Drop (free fall, caught just above the ground; not while looking up):
  Keyboard: E E, Controller: LB LB

Any time in the air
-------------------

- Tricks: the car turns freely with your aim; the hover keeps its height;
  forward also pushes: Keyboard: hold Q + Shift / Ctrl / A / D, Controller:
  hold RB + left stick
- Drop: Keyboard: Q Q, Controller: RB RB
- Fire the jets again: picks the car up; keep holding to rise, let go to drop
  onto the soft landing: Keyboard: E (once), Controller: LB (once)
- Back to the hover: Keyboard: E E, Controller: LB LB
- While rising: tilt the nose a little: Keyboard: Left Shift / Left Ctrl,
  Controller: left stick forward / back

Hops, ramp jumps and ledge drops are caught near the ground automatically. In
a jump or a drop, RT (W) only spins the wheels up, so you drive off fast when
you land; in the hover it climbs.

An option in plugins\RoadsterX.ini, [Gas] Infinite=1, gives an air reserve
that never runs out.

Leaving the car
---------------

Use the game's exit button (F, or Y on a controller). From that moment the
car's systems take no input, so nothing launches while you climb out.

Changing the controls
---------------------

Every key and button can be changed in plugins\RoadsterX.ini ([Keys], [Pad]
and [Controls]). Each line has a comment. To apply a change without
restarting, edit [Live] Serial (for example 0 to 1) and save.

KNOWN ISSUES
============

- One passenger: Roadster X is a two-seater, so only one companion can ride.
- Butterfly doors: companions sometimes take a moment to get in through the
  butterfly doors.
- Text files: the car's text uses the update\common\text\*8.gxt files. If
  another mod uses the same file names, one of the two loses its text. Tell us
  and we'll move ours.
- Weight: the car is very heavy on purpose, so it shoves other cars around in
  a crash.
- Testing: tested on an Apple Silicon Mac with CrossOver and GTA IV CE
  1.2.0.59. Windows reports are welcome.

CREDITS, TERMS AND SUPPORT
==========================

Credits
-------

- Author: Penandpaerdamn
- Built with:
  - Blender (https://www.blender.org/): the model is generated by our own
    Blender build script.
  - Python: our own tools write the game's model, texture and archive files
    (WFT, WTD, IMG) and the text files. The car's 49 sounds are synthesized
    with numpy: no third-party samples.
  - MinGW-w64: compiles the plugin (RoadsterX.asi).
  - No third-party code or assets are included in the download. It's built on
    the game's own vehicle skeleton template, with no Rockstar meshes,
    textures or sounds.
- Needs, but doesn't include: FusionFix
  (https://github.com/ThirteenAG/GTAIV.EFLC.FusionFix) by ThirteenAG and the
  FusionFix team, and Aru's C++ ScriptHook with the Complete Edition hook fix.
- Thanks to the GTA IV modding community, ThirteenAG and the FusionFix team,
  and Aru for ScriptHook.

AI use
------

Some mod sites require this disclosure.

Roadster X was made with AI coding assistants (Anthropic's Claude, through
Claude Code, and OpenAI Codex). The assistants wrote most of the code under
Penandpaerdamn's direction:

- the plugin (thrusters, flight, wing, panel, controls);
- the Blender model script;
- the file-format tools and the sound-synthesis scripts;
- these documents.

Penandpaerdamn designed the car and its controls, directed every change, chose
what shipped, and tested it in the game.

The model and its textures come from the build scripts, and the sounds from
the synthesis scripts. The download contains no AI-generated images, voices or
music.

Terms of use
------------

LICENSE.txt in this folder: free to play and show, no re-uploads, never sold.

Roadster X is an unofficial fan-made mod. It is not affiliated with, endorsed
by or sponsored by Rockstar Games or Take-Two Interactive. Grand Theft Auto
and Grand Theft Auto IV are trademarks of Take-Two Interactive Software.
